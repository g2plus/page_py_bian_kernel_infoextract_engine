# bian-kernel-infoExtract-engine

信息提取引擎核心模块


> 安装模块依赖
```python
pip install -r requiremenets.txt
```
