from abc import abstractmethod
from typing import TypeVar, Generic, Generator

from info_extract.extract_result import ExtractResult

from info_extract.abc_generator_handler import ABCGeneratorHandler

CONTENT = TypeVar('CONTENT', bound=ExtractResult)
RESULT = TypeVar('RESULT', bound=ExtractResult)


class ABCDataTraverser(ABCGeneratorHandler[CONTENT, RESULT], Generic[CONTENT, RESULT]):
    def __init__(self, name):
        super(ABCDataTraverser, self).__init__(name)

    @abstractmethod
    def handle(self, content: CONTENT = None) -> Generator[RESULT, None, None]:
        raise Exception("ABCDataTraverser未实现的抽象方法！")
