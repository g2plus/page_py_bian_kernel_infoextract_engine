#!/usr/bin/env Python
# -- coding: utf-8 --

"""
@version: v1.0
@author: liwei
@file: batch_size_condition.py
@Description: 
@time: 2023/9/24 12:32
"""
from typing import Set, Dict

from info_extract.abs_batch_condition import AbsBatchCondition


class BatchDiffValCondition(AbsBatchCondition):

    def __init__(self, diff_columns: Set):
        self.cur_val: Dict = {}
        assert diff_columns and len(diff_columns) > 0, "比较字段必须有值"
        self.diff_columns = diff_columns

    def next(self, pool, data) -> bool:
        if len(self.cur_val) > 0:
            diff = False
            for c in self.diff_columns:
                if self.cur_val[c] != data[c]:
                    diff = True
                    break
            if diff:
                for c in self.diff_columns:
                    self.cur_val[c] = data[c]
            return diff
        else:
            for c in self.diff_columns:
                self.cur_val[c] = data[c]
            return False
