#!/usr/bin/env Python
# -- coding: utf-8 --

"""
@version: v1.0
@author: liwei
@file: batch_size_condition.py
@Description: 
@time: 2023/9/24 12:32
"""
from typing import Callable, List, Any

from info_extract.abs_batch_condition import AbsBatchCondition


class BatchLambdaCondition(AbsBatchCondition):

    def __init__(self, batch_condition_fun: Callable[[List, Any], bool]):
        assert batch_condition_fun, "lambda函数不允许为null"
        self.batch_condition_fun = batch_condition_fun

    def next(self, pool, data) -> bool:
        return self.batch_condition_fun(pool, data)