#!/usr/bin/env Python
# -- coding: utf-8 --

"""
@version: v1.0
@author: liwei
@file: batch_size_condition.py
@Description: 
@time: 2023/9/24 12:32
"""
from info_extract.abs_batch_condition import AbsBatchCondition


class BatchSizeCondition(AbsBatchCondition):

    def __init__(self, batch_size=1000):
        self.batch_size = batch_size

    def next(self, pool, data) -> bool:
        return len(pool) >= self.batch_size
