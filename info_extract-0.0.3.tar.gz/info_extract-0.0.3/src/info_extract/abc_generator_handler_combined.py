#!/usr/bin/env Python
# -- coding: utf-8 --

"""
@version: v1.0
@author: liwei
@file: abc_generator_handler.py
@Description: 
@time: 2023/8/4 13:25
"""
from typing import Generator, Dict, List


from info_extract.abc_generator_handler import ABCGeneratorHandler
from info_extract.abs_generator_handler_organize import HandlerGroup, AbsGeneratorHandlerOrganize
from info_extract.handler_organizes.seq_handler_organize import SeqHandlerOrganize


class ABCCombinedGeneratorHandler(ABCGeneratorHandler):
    GROUP_DEF = "DEF"

    def __init__(self,
                 name,
                 handler_organize: AbsGeneratorHandlerOrganize = None,
                 is_iterator=True):
        """
        抽象组合处理器，组合处理逻辑的最抽象单元
        :param name:
        """
        super(ABCCombinedGeneratorHandler, self).__init__(name)
        self.groups: Dict[str, HandlerGroup] = {}
        self.children: Dict[str, ABCGeneratorHandler] = {}
        self.handler_organize: AbsGeneratorHandlerOrganize = handler_organize or SeqHandlerOrganize(self)
        self.handler_organize.parent =self
        self.handler_organize.groups = self.groups
        self.handler_organize.children = self.children
        self.is_iterator = is_iterator


    def init(self):
        for h in self.handler_organize.iterator_handle():
            h.init()

    def _add_child(self, child: ABCGeneratorHandler, group_name=GROUP_DEF):
        if group_name not in self.groups:
            self.groups[group_name] = HandlerGroup(group_name)
        self.children[child.name] = child
        child.parent = self
        if group_name in self.groups.keys():
            self.groups[group_name] = HandlerGroup(group_name)
        else:
            self.groups[group_name].add_member(child)

    def add_child(self, child: ABCGeneratorHandler, group_name=GROUP_DEF):
        self._add_child(child, group_name)

    def add_children(self, children: List[ABCGeneratorHandler]):
        for e in children:
            self.add_child(e)

    def get_group_handlers(self, name):
        return self.groups[name].get_members()

    def get_group(self, name):
        return self.groups[name]

    def handle(self, content=None) -> Generator:
        if self.is_iterator:
            yield from self.handler_organize.handle()
        else:
            result = []
            for h in self.handler_organize.iterator_handle():
                result.append(h.handle(content))
            yield result


    def start(self):
        for h in self.handler_organize.iterator_handle():
            h.start()

    def finish(self):
        for h in self.handler_organize.iterator_handle():
            h.finish()


    def print_structure_info(self, level=1):
        info = super().print_structure_info(level)
        for child in self.children.values():
            info = info + child.print_structure_info(level + 1)
        return info




if __name__ == '__main__':
    print(','.join(['\t' for i in range(10)]))
