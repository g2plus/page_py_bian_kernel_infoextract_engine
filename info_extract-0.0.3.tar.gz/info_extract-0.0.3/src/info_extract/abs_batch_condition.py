#!/usr/bin/env Python
# -- coding: utf-8 --

"""
@version: v1.0
@author: liwei
@file: abs_batch_condition.py
@Description: 
@time: 2023/9/23 10:48
"""
from abc import ABCMeta, abstractmethod


class AbsBatchCondition(metaclass=ABCMeta):

    @abstractmethod
    def next(self, pool, data) -> bool:
        pass
