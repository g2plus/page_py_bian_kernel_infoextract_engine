#!/usr/bin/env Python
# -- coding: utf-8 --

"""
@version: v1.0
@author: huangyc
@file: seq_handler_organize.py
@Description: 顺序Handler组织类
@time: 2023/9/20 13:26
"""
from typing import Generator, Dict

from info_extract.abc_generator_handler import ABCGeneratorHandler
from info_extract.abs_generator_handler_organize import AbsGeneratorHandlerOrganize, HandlerGroup


class SeqHandlerOrganize(AbsGeneratorHandlerOrganize):
    def __init__(self, parent: ABCGeneratorHandler,
                 groups: Dict[str, HandlerGroup]=None,
                 children: Dict[str, ABCGeneratorHandler]=None):
        super(SeqHandlerOrganize, self).__init__(parent, groups, children)

    def iterator_handle(self) -> Generator:
        for handler in self.children.values():
            yield handler

    def handle(self, content) -> Generator:
        for h in self.iterator_handle():
            yield from h.handle(content)
