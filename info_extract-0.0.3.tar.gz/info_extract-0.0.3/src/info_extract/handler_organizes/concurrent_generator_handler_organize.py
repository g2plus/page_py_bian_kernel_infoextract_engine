#!/usr/bin/env Python
# -- coding: utf-8 --

"""
@version: v1.0
@author: huangyc
@file: concurrent_generator_handler_organize.py
@Description: 并发Handler组织类
@time: 2023/9/20 11:20
"""
import traceback
from concurrent import futures
from enum import Enum
from multiprocessing import cpu_count
from typing import Generator, Dict, List

from basic_support.logger.logger_config import logger
from func_timeout import func_timeout, FunctionTimedOut

from info_extract.abc_generator_handler import ABCGeneratorHandler
from info_extract.abs_generator_handler_organize import AbsGeneratorHandlerOrganize, HandlerGroup


class ConCurrentTypeEnum(Enum):
    THREAD = "多线程方式"
    PROCESS = "多进程方式"


def single_processor(identifier, num_of_processor, handler_with_key, content, timeout: int) -> List:
    """
    单个并发处理
    @param identifier: 编号
    @param num_of_processor: processor总数量
    @param handler_with_key: handler对象列表
    @param content: 参数
    @param timeout: 超时
    @return:
    """
    handle_res = []
    for idx, (key, handler) in enumerate(handler_with_key):
        if idx % num_of_processor != identifier:
            continue
        logger.debug(f"处理器[{identifier}], 开始处理[{key} -> {handler.__class__.__name__}]")
        try:
            res = func_timeout(timeout, handler.handle, args=(content,))
            f_res = list(res) if res else res
            logger.debug(f"处理器[{identifier}], 处理完成[{key} -> {handler.__class__.__name__}]")
            handle_res.append((idx, f_res))
        except FunctionTimedOut as e:
            handle_res.append((idx, None))
            logger.exception(f"处理器[{identifier}], 处理[{key} -> {handler.__class__.__name__}], 发生超时异常")
            raise e
        except Exception as e:
            handle_res.append((idx, None))
            logger.exception(traceback.format_exc())
            raise e
    return handle_res


class ConcurrentGeneratorHandlerOrganize(AbsGeneratorHandlerOrganize):
    def __init__(self, parent: ABCGeneratorHandler,
                 groups: Dict[str, HandlerGroup] = None,
                 children: Dict[str, ABCGeneratorHandler] = None,
                 timeout: int = None,
                 num_of_processor: int = None,
                 concurrent_type: ConCurrentTypeEnum = ConCurrentTypeEnum.THREAD):
        """
        并发Handler组织类
        @param parent: 父handler
        @param groups: handler分组信息
        @param children: 子handlers
        @param timeout: 单任务超时时间(单位秒), None表示不限制
        @param num_of_processor: 并发数量
        @param concurrent_type: 并发类型(多线程或多进程)
        """
        super(ConcurrentGeneratorHandlerOrganize, self).__init__(parent=parent, groups=groups, children=children)
        # 任务超时
        self.timeout = timeout or 1e6
        # 并发数量
        self.num_of_processor = num_of_processor or cpu_count()
        # 并发类型(多线程或多进程)
        self.concurrent_type = concurrent_type
        # 执行器池子
        self.executor_pool = futures.ProcessPoolExecutor if self.concurrent_type == ConCurrentTypeEnum.PROCESS else futures.ThreadPoolExecutor

    def iterator_handle(self) -> Generator:
        for key in self._iterator_handle_key():
            yield self.children[key]

    def _iterator_handle_key(self) -> Generator:
        for key in self.children.keys():
            yield key

    def handle(self, content) -> Generator:
        logger.info(f"{self.concurrent_type.value}任务开始执行")
        with self.executor_pool(max_workers=self.num_of_processor) as executor:
            # 获取所有的handler
            handlers = list(self.iterator_handle())
            keys = list(self._iterator_handle_key())

            # 提交任务
            tasks = []
            for identifier in range(self.num_of_processor):
                task = executor.submit(single_processor, identifier=identifier, num_of_processor=self.num_of_processor,
                                       handler_with_key=zip(keys, handlers), content=content, timeout=self.timeout)
                tasks.append(task)

            completed_res = []
            for future in futures.as_completed(tasks):
                result = future.result()
                if hasattr(result, '__iter__'):
                    completed_res.extend(result)
                else:
                    completed_res.append(result)
            logger.info(f"{self.concurrent_type.value}任务执行完成, 开始返回结果")

            # 保持结果有序
            completed_res.sort(key=lambda k: k[0])

            for _, output in completed_res:
                for o in output:
                    yield o
            logger.info(f"{self.concurrent_type.value}执行完毕")

