#!/usr/bin/env Python
# -- coding: utf-8 --

"""
@version: v1.0
@author: liwei
@file: unit_handler_organize.py
@Description: 
@time: 2023/10/7 13:30
"""
from typing import Dict, Generator

from info_extract.abc_generator_handler import ABCGeneratorHandler
from info_extract.abs_generator_handler_organize import AbsGeneratorHandlerOrganize, HandlerGroup


class UnitHandlerOrganize(AbsGeneratorHandlerOrganize):
    def __init__(self, parent: ABCGeneratorHandler,
                 groups: Dict[str, HandlerGroup] = None,
                 children: Dict[str, ABCGeneratorHandler] = None):
        super(UnitHandlerOrganize, self).__init__(parent, groups, children)

    def iterator_handle(self) -> Generator:
        for key in self.children.keys():
            yield self.children[key]

    def handle(self, content) -> Generator:
        handlers = [h for h in self.iterator_handle()]
        i = 0
        c = content
        r = None
        while i < len(handlers):
            if i == 0:
                r = self._handle(handlers[i], c)
            else:
                r = self._handle(handlers[i], r)
            # c = yield from self._handle(handlers[i], c)
            i += 1
        return r

    def _handle(self, handler, content) -> Generator:
        if isinstance(content, Generator):
            for c in content:
                yield from handler.handle(c)
        else:
            yield from handler.handle(content)