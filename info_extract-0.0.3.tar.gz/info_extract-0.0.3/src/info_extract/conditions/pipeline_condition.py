#!/usr/bin/env Python
# -- coding: utf-8 --

"""
@version: v1.0
@author: liwei
@file: pipeline_condition.py
@Description: 
@time: 2023/8/10 10:37
"""
from typing import Dict, Callable, List

from info_extract.conditions.state_content_block_condition_abs import ABSStateContentBlockCondition


class ConditionPipe:
    def __init__(self, name, condition_func: Callable):
        self.name = name
        self.condition_fun: Callable = condition_func
        self.inputs = []

    def add_input(self, next_pipe):
        self.inputs.append(next_pipe)

    def calCondition(self, *content):
        if len(self.inputs) < 1:
            return self.condition_fun(*content)
        else:
            c = []
            for i in self.inputs:
                r = i.calCondition(*content)
                if r:
                    c.append(r)
            return self.condition_fun(c)


class PipelineCondition(ABSStateContentBlockCondition):
    """
        正则条件
    """

    def __init__(self, type):
        super(ABSStateContentBlockCondition, self).__init__(type, {})
        self.last_pipe: ConditionPipe = None
        self.cur_pipe: ConditionPipe = None

    def start(self):
        self.cur_pipe = self.last_pipe

    def append(self, condition: Callable, input_names: List[str], output: str):
        assert output not in self.condition, "pipi[%s],已经存在" % output
        pipe: ConditionPipe = ConditionPipe(output, condition)
        self.last_pipe = pipe
        for name in input_names:
            c = self.condition[name]
            assert c, "前置pipe[%s],不允许为None" % name
            pipe.add_input(c)
        self.condition[output] = pipe

    def calCondition(self, *content) -> int:
        return self.last_pipe.calCondition(*content)
