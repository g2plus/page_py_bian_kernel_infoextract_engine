#!/usr/bin/env Python
# -- coding: utf-8 --

"""
@version: v1.0
@author: liwei
@file: state_content_block_condition_abs.py
@Description: 
@time: 2023/8/10 13:33
"""
from info_extract.abc_content_block_condition import ABCContentBlockCondition


class ABSStateContentBlockCondition(ABCContentBlockCondition):

    def __init__(self, type, condition):
        """
        带状态的规则抽象类，调用前先start重置状态
        """
        super().__init__(type, condition)

    def start(self):
        pass
