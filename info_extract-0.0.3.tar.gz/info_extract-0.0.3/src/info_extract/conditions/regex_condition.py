import re

from info_extract.abc_content_block_condition import ABCContentBlockCondition


class RegexCondition(ABCContentBlockCondition):
    """
    正则条件
    """

    def __init__(self, type, regex_text):
        super(ABCContentBlockCondition, self).__init__(type, regex_text)
        self.regexText = regex_text
        self.pattern = re.compile(regex_text)

    def calCondition(self, *content) -> int:
        res = self.pattern.search(content)
        if res:
            return res.span()[1]
        else:
            return -1
