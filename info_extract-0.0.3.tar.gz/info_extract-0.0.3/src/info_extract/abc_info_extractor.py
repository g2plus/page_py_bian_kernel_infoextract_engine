from ctypes import Array
from typing import Dict, List

from basic_support.logger.logger_config import logger

from info_extract.abc_content_block_searcher import ABCContentBlockSearcher
from info_extract.abc_extract_rule import ABCExtractRule
from info_extract.abc_generator_handler import ABCGeneratorHandler
from info_extract.abc_info_collector_batch_wrapper import ABCInfoCollectorBatchWrapper
from info_extract.base_info_collector import BaseInfoCollector
from info_extract.extract_result import ExtractResult


class ABCInfoExtractor(ABCGeneratorHandler):

    def __init__(self, name):
        """
               内容提取器
               :param name:
               """
        super(ABCInfoExtractor, self).__init__(name)
        self.info_collectors: Dict[str, List[BaseInfoCollector]] = None
        self.contentSearcher: ABCContentBlockSearcher = None
        self.extractRule: dict = {}
        # 搜索内容块时的过滤条件
        self.search_filter_content_block_types: List[str] = []

    def start(self):
        for k, collectors in self.info_collectors.items():
            for r in self.extractRule.values():
                if k == r.name:
                    for c in collectors:
                        c.start()
                        logger.info('[%s]启动对[%s]的收集' % (c.name, r.name))


    def finish(self):
        for k, collectors in self.info_collectors.items():

            for r in self.extractRule.values():
                if k == r.name:
                    for c in collectors:
                        if isinstance(c, ABCInfoCollectorBatchWrapper):
                            c.last_handle()
                            logger.info('[%s]执行收尾工作' % c.name)
                        c.finish()
                        logger.info('[%s]结束对[%s]的收集' % (c.name, r.name))




    def set_info_collectors(self, info_collectors: Dict[str, BaseInfoCollector]):
        self.info_collectors = info_collectors

    def set_content_searcher(self, content_searcher):
        self.contentSearcher = content_searcher

    def add_extract_rule(self, content_block_name: str, rule: ABCExtractRule):
        self.extractRule[content_block_name] = rule

    def build_result(self, content: ExtractResult) -> ExtractResult:
        pass

    def set_filter_content_block_types(self, filter_content_block_types: List[str]):
        """
        符合条件的内容块才被输出
        :param filter_content_block_types:
        :return:
        """
        self.search_filter_content_block_types = filter_content_block_types

    def wrap_result(self, content: ExtractResult) -> ExtractResult:
        pass
