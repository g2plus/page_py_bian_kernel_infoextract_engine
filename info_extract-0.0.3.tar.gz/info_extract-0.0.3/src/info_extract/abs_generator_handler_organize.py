#!/usr/bin/env Python
# -- coding: utf-8 --

"""
@version: v1.0
@author: huangyc
@file: abs_generator_handler_organize.py
@Description: handler组织类
@time: 2023/9/20 11:12
"""

from abc import abstractmethod
from typing import Generator, Dict, OrderedDict, Generic, TypeVar, Set

from basic_support.logger.logger_config import logger

from info_extract.abc_generator_handler import ABCGeneratorHandler


class HandlerGroup:
    def __init__(self, name: str):
        """
        handler分组
        @param name: 组名
        """
        self.name = name
        self.members = {}

    def add_member(self, handler: ABCGeneratorHandler):
        self.members[handler.name] = handler

    def get_member(self, name):
        return self.members[name]

    def get_members(self):
        return self.members.values()


class AbsGeneratorHandlerOrganize:
    def __init__(self, parent: ABCGeneratorHandler,
                 groups: Dict[str, HandlerGroup] = None,
                 children: Dict[str, ABCGeneratorHandler] = None):
        """
        children 迭代方式的组织类，可实现不同的迭代逻辑，例如顺序，逐个，嵌套，等等
        :param parent:
        :param groups:
        :param children:
        """
        self.parent: parent
        self.groups: Dict[str, HandlerGroup] = groups
        self.children: Dict[str, ABCGeneratorHandler] = children

    @abstractmethod
    def iterator_handle(self) -> Generator:
        raise Exception('ABCGeneratorHandlerOrganize方法必须要继承')

    @abstractmethod
    def handle(self, content) -> Generator:
        raise Exception('ABCGeneratorHandlerOrganize方法必须要继承')



ORGANIZABLE = TypeVar('ORGANIZABLE')

class HandlerOrganizer(Generic[ORGANIZABLE]):

    def __init__(self, org_children: OrderedDict[str, ORGANIZABLE]):
        assert org_children and len(org_children) > 0, "组织内的成员必须有值"
        self.org_children: OrderedDict[str, ORGANIZABLE] = org_children
        self.must_fill: Set = set()
        for k, v in self.org_children.items():
            if v:
                self.must_fill.add(k)

    def exist_org_child(self, name):
        return name in self.org_children

    def set_org_child(self, name, v: ORGANIZABLE):
        assert name in self.org_children, '组织中找不到指定的子节点名称[%s]' % name
        assert v, '%s不允许为null' % name
        self.org_children[name] = v

    def _init_children(self):
        logger.info('开始组织子节点,%s为必填节点' % self.must_fill)
        for child, v in self.org_children.items():
            if v is None:
                assert child not in self.must_fill, '%s不允许为null' % child
                logger.info('节点[%s]为空，未加入组织' % child)
            else:
                self.add_child(v)
                logger.info('新增节点[%s]' % child)
