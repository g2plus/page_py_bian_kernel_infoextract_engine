from collections import defaultdict
from ctypes import Array
from typing import List, Generic

from info_extract.abc_content_block import ABCContentBlock

from typing import TypeVar

INFO = TypeVar('INFO')


class ExtractResult(Generic[INFO]):

    def __init__(self):
        self.content_blocks: List[ABCContentBlock] = []  # 提取过程中获取到的内容块
        self.id = None  # 数据标识
        self.res = None  # 数据来源
        self.content = defaultdict(list)

    def set_res(self, res):
        self.res = res

    def set_id(self, id):
        self.id = id

    def add_content_block(self, content_block: ABCContentBlock):
        self.content_blocks.append(content_block)

    def add_info(self, info: INFO):
        pass
