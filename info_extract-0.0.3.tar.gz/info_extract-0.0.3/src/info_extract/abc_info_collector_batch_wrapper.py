from typing import Iterator, List, Any, TypeVar, Callable

from basic_support.logger.logger_config import logger

from info_extract.abc_info_collector_wrapper import ABCInfoCollectorWrapper
from info_extract.base_info_collector import BaseInfoCollector
from info_extract.abs_batch_condition import AbsBatchCondition
from info_extract.batch_conditions.batch_size_condition import BatchSizeCondition

EXTRACT_RESULT = TypeVar('EXTRACT_RESULT')
HANDLER_OUTPUT = TypeVar('HANDLER_OUTPUT')
OUTPUT = TypeVar('OUTPUT')


class ABCInfoCollectorBatchWrapper(ABCInfoCollectorWrapper[EXTRACT_RESULT, HANDLER_OUTPUT, OUTPUT]):
    def __init__(self, name,
                 handler: BaseInfoCollector,
                 infos: Iterator,
                 infos_to_result: Callable[[Any], List] = None,
                 row_to_infos: Callable[[Any, Any], Any] = None,
                 condition: AbsBatchCondition = None,
                 last_handle=False):
        """
        抽象迭代处理器，迭代处理逻辑的最抽象单元
        :param name:
        """
        super(ABCInfoCollectorBatchWrapper, self).__init__(name, handler)

        self.condition = condition if condition else BatchSizeCondition(1000)
        self.is_last_handle = last_handle

        self.infos = infos if infos is not None else []

        def def_infos_to_result(infos):
            result = infos
            infos.clear()
            return result

        self.infos_to_result = infos_to_result if infos_to_result else def_infos_to_result

        def def_row_to_infos(row, infos):
            infos.append(row)

        self.row_to_infos = row_to_infos if row_to_infos else def_row_to_infos

    def add_info(self, content: EXTRACT_RESULT = None) -> List[OUTPUT]:
        gen = self.handler.add_info(content)
        result = []
        if gen:
            for row in gen:
                if isinstance(row, List):
                    logger.debug("[%s]上游数据为List集合，进迭代处理" % self.handler.name)
                    for one in row:
                        r = self.wrapper_one_data(one)
                        if r:
                            result.extend(r)
                else:
                    r = self.wrapper_one_data(row)
                    if r:
                        result.extend(r)
            return result
        else:
            return None

    def wrapper_one_data(self, one):
        if not self.is_last_handle and self.condition.next(self.infos, one):
            logger.debug("[%s]批次条件满足，输出结果: %s" % (self.handler.name, self.infos))
            result = self.infos_to_result(self.infos)
            self.row_to_infos(one, self.infos)
            return result
        else:
            self.row_to_infos(one, self.infos)
            return None

    def last_handle(self) -> List[OUTPUT]:
        if isinstance(self.handler, ABCInfoCollectorBatchWrapper):
            for row in self.handler.last_handle():
                if isinstance(row, List):
                    logger.debug("[%s]上游数据为List集合，进迭代处理" % self.handler.name)
                    for one in row:
                        self.row_to_infos(one, self.infos)
                else:
                    self.row_to_infos(row, self.infos)
        return self.infos_to_result(self.infos)
