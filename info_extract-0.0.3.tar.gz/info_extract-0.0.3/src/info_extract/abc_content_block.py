from typing import Dict


class ABCContentBlock:
    def __init__(self, rule_type, content, start=-1, end=-1):
        """
        内容搜索器从内容来源提取到的内容块
        :param rule_type: 提取规则类型
        :param content: 内容
        :param start: 起始
        :param end: 截止
        """
        self.rule_type = rule_type
        self.content = content
        self.start = start
        self.end = end
        self.res_id = None  # 内容来源标识，内容块可能没有内容来源标识
        self.include_columns:Dict = {}

    def set_res_id(self, res_id):
        self.res_id = res_id

    def add_include_columns(self,content:Dict):
        self.include_columns.update(content)