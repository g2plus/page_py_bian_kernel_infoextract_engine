from typing import Generator, List, TypeVar, Generic

from info_extract.abc_generator_handler import ABCGeneratorHandler

EXTRACT_RESULT = TypeVar('EXTRACT_RESULT')
OUTPUT = TypeVar('OUTPUT')


class BaseInfoCollector(Generic[EXTRACT_RESULT, OUTPUT]):
    """
    信息收集器
    """

    def __init__(self, name):
        self.name = name
        self.rule_names = []

    def add_rule_name(self, rule_name):
        self.rule_names.append(rule_name)

    def add_info(self, content: EXTRACT_RESULT = None) -> List[OUTPUT]:
        if isinstance(content, List):
            return content
        else:
            return [content]

    def start(self):
        pass

    def finish(self):
        pass

