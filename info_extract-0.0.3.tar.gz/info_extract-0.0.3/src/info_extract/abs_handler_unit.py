#!/usr/bin/env Python
# -- coding: utf-8 --

"""
@version: v1.0
@author: liwei
@file: abs_handler_unit.py
@Description: 
@time: 2023/10/7 13:33
"""
from typing import TypeVar, OrderedDict

from basic_support.logger.logger_config import logger
from info_extract.abc_pipeline import ABCPipeline

from info_extract.abc_pipe import ABCPipe
from info_extract.abs_generator_handler_organize import HandlerOrganizer, AbsGeneratorHandlerOrganize
from info_extract.handler_organizes.unit_handler_organize import UnitHandlerOrganize

ORGANIZABLE = TypeVar('ORGANIZABLE')
class AbsHandlerUnit(ABCPipe, HandlerOrganizer[ORGANIZABLE]):

    def __init__(self,
                 db_config,
                 org_children: OrderedDict[str, ORGANIZABLE],
                 handler_organize: AbsGeneratorHandlerOrganize = None,
                 engine: ABCPipeline = None,
                 backward_iteration=False,
                 is_iterator=True,
                 name="AbsHandlerUnit"):
        organize = UnitHandlerOrganize(self) if not handler_organize else handler_organize
        ABCPipe.__init__(self,
                         name=name,
                         backward_iteration=backward_iteration,
                         handler_organize=organize,
                         is_iterator=is_iterator)
        HandlerOrganizer.__init__(self, org_children)
        self.set_parent(engine)
        self.db_config = db_config

    def init(self):
        logger.info('[%s]开始初始化'%self.name)
        self._init_children()
        ABCPipe.init(self)