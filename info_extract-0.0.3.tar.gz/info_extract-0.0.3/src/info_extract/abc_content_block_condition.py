class ABCContentBlockCondition:

    def __init__(self, type, condition):
        """
        规则抽象类
        """
        self.type = type;
        self.condition = condition


    def calCondition(self, *content) -> int:
        """
        判断满足条件，并返回满足条件的位置信息
        """
        pass
