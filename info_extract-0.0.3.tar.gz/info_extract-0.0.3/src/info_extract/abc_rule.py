class ABCRule:
    '''
    规则抽象类
    '''

    def __init__(self, type, name):
        self.type = type
        self.name = name
