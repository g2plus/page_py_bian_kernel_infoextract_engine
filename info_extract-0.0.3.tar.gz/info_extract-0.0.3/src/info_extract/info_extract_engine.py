from ctypes import Array
from typing import Generator, Dict, List

from basic_support.logger.logger_config import logger
from info_extract.abc_data_traverser import ABCDataTraverser
from info_extract.abc_generator_handler_combined import HandlerGroup
from info_extract.base_info_collector import BaseInfoCollector
from info_extract.abc_info_extractor import ABCInfoExtractor
from info_extract.abc_pipeline import ABCPipeline
from info_extract.info_extract_step import InfoExtractStep


class InfoExtractEngine(ABCPipeline):
    GROUP_IN_DATA_TRAVERSER = 'input_data_traverser'

    GROUP_OUT_DATA_TRAVERSER = 'output_data_traverser'

    def __init__(self, name):
        """
        内容提取引擎
        """
        super(InfoExtractEngine, self).__init__(name)
        self.infoCollectors: Dict[str, BaseInfoCollector] = {}
        self.groups[InfoExtractEngine.GROUP_IN_DATA_TRAVERSER] = HandlerGroup(InfoExtractEngine.GROUP_IN_DATA_TRAVERSER)
        self.groups[InfoExtractEngine.GROUP_OUT_DATA_TRAVERSER] = HandlerGroup(
            InfoExtractEngine.GROUP_OUT_DATA_TRAVERSER)

    def set_input_data_traverser(self, data_traverser: ABCDataTraverser):
        assert self.first_pipe is None, "设置输入迭代器必须是第一步"
        step = InfoExtractStep(self.name + '-[' + data_traverser.name + ']', self)
        step.add_child(data_traverser)
        self.insert_first_pipe(step, InfoExtractEngine.GROUP_IN_DATA_TRAVERSER)

    def get_input_data_traverser(self):
        return self.get_first_pipe()

    def set_output_data_traverser(self, data_traverser: ABCDataTraverser):
        assert self.last_pipe, "设置输出迭代器前需要有append_extractor_step"
        step = InfoExtractStep(self.name + '-第' + str(len(self.children) + 1) + '步', self)
        step.add_child(data_traverser)
        self.add_child(step, InfoExtractEngine.GROUP_OUT_DATA_TRAVERSER)

    def get_output_data_traverser(self):

        return self.get_last_pipe()

    def append_extractor_step(self, extractors: List[ABCInfoExtractor]):
        assert self.first_pipe, "增加抽取步骤前，请先设置set_output_data_traverser"

        """
        新增步骤，在最后一个步骤处APPEND
        :param extractors:
        :return:
        """
        for extractor in extractors:
            extractor.set_info_collectors(self.infoCollectors)
        step = InfoExtractStep(self.name + '-第' + str(len(self.children) + 1) + '步', self)
        step.add_children(extractors)
        self.add_child(step)

    def add_info_collector(self, rule_names: Array, collectors: Array):
        for rule_name in rule_names:
            self.infoCollectors[rule_name] = collectors

    def print_process(self):
        str = self.name+" 处理过程："
        cur_step = self.get_first_pipe()
        while cur_step:
            str = str + cur_step.name+" ->"
            cur_step = cur_step.get_next_pipe()
        return str

    def extract(self) -> Generator:
        self.start()
        logger.info('[' + self.name + ']结构如下：\n' + self.print_structure_info())
        logger.info(self.print_process())
        yield from self.handle()
        gen = self.finish()
        if gen:
            yield from gen

    def backward_extract(self, content) -> Generator:
        yield from self.handle(content)


