from typing import Tuple, Any, List, TypeVar, Generic

from info_extract.abc_rule import ABCRule
from info_extract.abc_content_block import ABCContentBlock

EXTRACT_RESULT = TypeVar('EXTRACT_RESULT')


class ABCExtractRule(ABCRule, Generic[EXTRACT_RESULT]):

    def __init__(self, name):
        super(ABCExtractRule, self).__init__('ExtractRule', name)

    def extract(self, content_block: ABCContentBlock) -> EXTRACT_RESULT:
        """
        根据搜索器获取到的内容块，按规则抓取内容，返回内容结果，
        返回提取到的结果 EXTRACT_RESULT
        :param content_block:
        """
        pass
