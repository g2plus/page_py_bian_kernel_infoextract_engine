from typing import Generator, List, Any

from info_extract.extract_results.dict_extract_result import DictExtractResult

from info_extract.abc_data_traverser import ABCDataTraverser


class MemoryDictTraverser(ABCDataTraverser[List, Any]):
    """
    内存字典遍历器，经常用于测试数据调试
    """

    def __init__(self, content: list, name='内存dict遍历器'):
        super(MemoryDictTraverser, self).__init__(name)
        self.content: list = content

    def handle(self, content=None) -> Generator[Any, None, None]:
        yield from [DictExtractResult(c) for c in self.content]
