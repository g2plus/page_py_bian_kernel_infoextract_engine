import json
from typing import Generator, Any

from basic_support.comm_funcs.io_utils import read_from_file, print_to_file, write_to_file
from info_extract.abc_data_traverser import ABCDataTraverser
from info_extract.extract_results.dict_extract_result import DictExtractResult


class FileTraverser(ABCDataTraverser[Any, DictExtractResult]):

    def __init__(self, file_path=None, is_read=True, read_start_lines=0, name='文件迭代器'):
        super(FileTraverser, self).__init__(name)
        self.file_path = file_path
        self.is_read = is_read
        self.read_start_lines = read_start_lines


    def handle(self, content: DictExtractResult = None) -> Generator[DictExtractResult, None, None]:
        if self.is_read:
            idx = -1
            with read_from_file(self.file_path) as f:
                for line in f:
                    idx += 1
                    if idx >= self.read_start_lines:

                        yield DictExtractResult(json.loads(line.strip()))
                    else:
                        continue

        else:
            with write_to_file(self.file_path) as f:
                f.write(json.dumps(content.data, ensure_ascii=False))
                yield content