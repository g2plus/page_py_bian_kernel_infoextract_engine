from typing import Generator, Callable, Any, Dict, List, Tuple, Set, TypeVar, Generic

from basic_support.logger.logger_config import logger

from info_extract.abs_batch_condition import AbsBatchCondition
from info_extract.batch_conditions.batch_size_condition import BatchSizeCondition
from info_extract.extract_result import ExtractResult

from info_extract.abc_data_traverser_wrapper import ABCDataTraverserWrapper

from info_extract.abc_data_traverser import ABCDataTraverser

CONTENT = TypeVar('CONTENT', bound=ExtractResult)
INFO = TypeVar('INFO')
RESULT = TypeVar('RESULT', bound=ExtractResult)



class AbsDataTraverseBatchWrapper(ABCDataTraverserWrapper[CONTENT, RESULT], Generic[CONTENT, INFO, RESULT]):

    def __init__(self,
                 handler: ABCDataTraverser,
                 wrap_func: Callable[[CONTENT], INFO | List[INFO]],
                 batch_condition: AbsBatchCondition = None,
                 name="批量操作包装迭代器"):
        super(AbsDataTraverseBatchWrapper, self).__init__(handler, name)
        self.wrap_func: Callable[[CONTENT], INFO | List[INFO]] = wrap_func
        self.infos: List[INFO] = []
        self.is_last = False
        self.batch_condition = batch_condition if batch_condition else BatchSizeCondition(1000)

    def wrap(self, data: CONTENT) -> RESULT | Generator[RESULT, None, None] | List[RESULT]:
        if data:


            if self.wrap_func:
                row = self.wrap_func(self.content_to_warp(data))
            else:
                row = self.content_to_warp(data)
            if row:
                if isinstance(row, List):
                    for r in row:
                        if self.batch_condition.next(self.infos, r) or self.is_last:
                            self.do_batch_wrap(self.infos)
                            logger.debug('[%s]已遍历数据')
                            self.infos = []
                        self.infos.append(self.result_to_info(r))
                        yield r
                else:
                    if self.batch_condition.next(self.infos,row) or self.is_last:
                        self.do_batch_wrap(self.infos)
                        logger.debug('[%s]已遍历数据')
                        self.infos = []
                    self.infos.append(self.result_to_info(row))
                    return row
            else:
                return None

    def content_to_warp(self, data: CONTENT) -> Any:
        return data

    def result_to_info(self, data: RESULT) -> INFO:
        """
        结果如何转为Infos临时保持的对象,默认什么都不做，试用于结果和do_batch_wrap入参不一致时
        :param data:
        """
        return data

    def do_batch_wrap(self, data: List[INFO]):
        """
        批量包装操作的具体操作实现，必须要实现该方法
        :param data:
        """
        raise Exception("AbsDataTraverseBatchWrapper未实现的抽象方法[do_batch_wrap]！")

    def finish(self):
        self.is_last = True
        gen = self.handler.finish()
        if gen:
            yield from self.iterator_wrap(gen)
        if len(self.infos) > 0:
            self.do_batch_wrap(self.infos)
        self.is_last = False
        self.infos = []
