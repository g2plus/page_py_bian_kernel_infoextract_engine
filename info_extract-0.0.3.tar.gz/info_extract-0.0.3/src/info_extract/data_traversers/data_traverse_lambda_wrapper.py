from typing import Callable, TypeVar, Generator, Generic

from info_extract.extract_result import ExtractResult

from info_extract.abc_data_traverser import ABCDataTraverser
from info_extract.abc_data_traverser_wrapper import ABCDataTraverserWrapper

CONTENT = TypeVar('CONTENT', bound=ExtractResult)
RESULT = TypeVar('RESULT', bound=ExtractResult)


class DataTraverseLambdaWrapper(ABCDataTraverserWrapper[CONTENT, RESULT], Generic[CONTENT, RESULT]):
    """
    数据遍历包装器，通过写包装表达式对遍历过程的原始数据进行包装，转换成新的结构
    """

    def __init__(self, data_traverser: ABCDataTraverser,
                 wrapper_func: Callable[[CONTENT], RESULT], name="lambda遍历包装器"):
        super(DataTraverseLambdaWrapper, self).__init__(data_traverser, name)
        self.wrapper_func = wrapper_func

    def wrap(self, data: CONTENT) -> Generator[RESULT, None, None]:
        yield self.wrapper_func(data)
