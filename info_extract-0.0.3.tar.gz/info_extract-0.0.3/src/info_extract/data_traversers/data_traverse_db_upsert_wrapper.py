from typing import Generator, Callable, Any, Dict, List, Tuple, Set

from basic_support.data_access.connection.pool_impl.rdb_pool import rdb_dao_creator

from info_extract.abc_data_traverser import ABCDataTraverser
from info_extract.batch_conditions.batch_size_condition import BatchSizeCondition
from info_extract.data_traversers.data_traverse_batch_wrapper_abs import AbsDataTraverseBatchWrapper, INFO, RESULT, \
    CONTENT
from info_extract.extract_results.dict_extract_result import DictExtractResult


class DataTraverseDBUpsertWrapper(AbsDataTraverseBatchWrapper[DictExtractResult, Dict, DictExtractResult]):

    def __init__(self,
                 data_traverser: ABCDataTraverser,
                 db_config,
                 table_name: str,
                 conflict: Tuple[str],
                 row_wrap: Callable[[DictExtractResult], List[DictExtractResult] | DictExtractResult],
                 ignore_cols: Set[str] = None,
                 update_cols: Tuple[str] = None,
                 batch_size: int = 1000,
                 name='数据库upsert数据迭代包装器'):
        super(DataTraverseDBUpsertWrapper, self).__init__(data_traverser, row_wrap, BatchSizeCondition(batch_size), name)
        self.db_config = db_config
        self.dao = rdb_dao_creator.get_rdb_pool(self.db_config)
        self.table_name = table_name
        assert conflict, '冲突字段不允许为空'
        assert row_wrap, '解析表达式不允许为空'
        self.conflict = conflict
        self.update_cols = update_cols
        self.ignore_cols: Set[str] = ignore_cols or []

    def content_to_warp(self, data: DictExtractResult) -> Dict:
        return data.data

    def result_to_info(self, data: DictExtractResult) -> Dict:
        return data.data

    def do_batch_wrap(self, infos: List[INFO]):
        self.dao.upsert_batch(self.table_name,
                              [{k: v for k, v in one.items() if k not in self.ignore_cols} for one in
                               infos],
                              self.conflict, update_cols=self.update_cols)

    # def finish(self):
    #     self.dao.upsert_batch(self.table_name,
    #                           [{k: v for k, v in one.items() if k not in self.ignore_cols} for one in self.infos],
    #                           self.conflict, update_cols=self.update_cols)
    #     self.infos = []
