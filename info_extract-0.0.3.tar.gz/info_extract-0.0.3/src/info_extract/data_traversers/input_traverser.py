from typing import Generator, List, Any

from info_extract.abc_data_traverser import ABCDataTraverser


class InputDictTraverser(ABCDataTraverser[List, Any]):
    """
    外部入参遍历器,只是作为外部数据的迭代入口
    """

    def __init__(self, name='外部入参遍历器'):
        super(InputDictTraverser, self).__init__(name)

    def handle(self, content=None) -> Generator[Any, None, None]:
        yield from self.content
