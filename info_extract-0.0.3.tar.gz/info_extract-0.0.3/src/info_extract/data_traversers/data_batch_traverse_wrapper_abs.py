from typing import Generator, Callable, Any, Dict, List, Tuple, Set, TypeVar, Generic

from basic_support.logger.logger_config import logger

from info_extract.extract_result import ExtractResult

from info_extract.abc_data_traverser_wrapper import ABCDataTraverserWrapper

from info_extract.abc_data_traverser import ABCDataTraverser

CONTENT = TypeVar('CONTENT', bound=ExtractResult)
INFO = TypeVar('INFO')
RESULT = TypeVar('RESULT', bound=ExtractResult)


class AbsDataBatchTraverseWrapper(ABCDataTraverserWrapper[CONTENT, RESULT], Generic[CONTENT, INFO, RESULT]):

    def __init__(self,
                 handler: ABCDataTraverser,
                 batch_size=1000,
                 name="批量操作包装迭代器"):
        super(AbsDataBatchTraverseWrapper, self).__init__(handler, name)
        self.batch_size = batch_size
        self.infos: List[INFO] = []
        self.is_last = False


    def wrap(self, data: CONTENT) -> RESULT | Generator[RESULT, None, None] | List[RESULT]:
        if data:
            self.content_to_warp(data)
            if len(self.infos) > self.batch_size or self.is_last:
                result = self.do_batch_wrap(self.infos)
                logger.debug('[%s]已遍历数据')
                self.infos = []
                return result
            else:
                return None
        else:
            return None

    def content_to_warp(self, data: CONTENT) -> Any:
        return data


    def do_batch_wrap(self, data: List[INFO]) -> List[RESULT]:
        """
        批量包装操作的具体操作实现，必须要实现该方法
        :param data:
        """
        raise Exception("AbsDataTraverseBatchWrapper未实现的抽象方法[do_batch_wrap]！")


    def finish(self):
        self.is_last = True
        gen = self.handler.finish()
        if gen:
            yield from self.iterator_wrap(gen)
        self.is_last = False
        self.infos = []