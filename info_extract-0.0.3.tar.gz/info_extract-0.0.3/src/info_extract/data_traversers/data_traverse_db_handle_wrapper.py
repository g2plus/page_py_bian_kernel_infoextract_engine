from typing import Generator, Callable, Any, Dict, List

from basic_support.data_access.connection.pool_impl.rdb_pool import rdb_dao_creator

from info_extract.abc_data_traverser import ABCDataTraverser
from info_extract.batch_conditions.batch_size_condition import BatchSizeCondition
from info_extract.data_traversers.data_traverse_batch_wrapper_abs import AbsDataTraverseBatchWrapper, INFO, RESULT
from info_extract.extract_results.dict_extract_result import DictExtractResult


class DataTraverseDBHandleWrapper(AbsDataTraverseBatchWrapper[DictExtractResult, Dict, DictExtractResult]):

    def __init__(self,
                 data_traverser: ABCDataTraverser,
                 db_config, sql=None,
                 row_wrap: Callable[[DictExtractResult], DictExtractResult | List[DictExtractResult]] = None,
                 batch_size: int = 1000,
                 name='数据库操作数据迭代包装器'):

        super(DataTraverseDBHandleWrapper, self).__init__(data_traverser, row_wrap, BatchSizeCondition(batch_size), name)

        self.db_config = db_config
        self.dao = rdb_dao_creator.get_rdb_pool(self.db_config)
        self.sql = sql

    def setSQL(self, sql):
        self.sql = sql

    def content_to_warp(self, data: DictExtractResult) -> Dict:
        return data.data

    def do_batch_wrap(self, infos: List[INFO]):
        self.dao.execute_sql_with_params_list_multi_threads(self.sql, infos)

    def result_to_info(self, data: DictExtractResult) -> Dict:
        return data.data


