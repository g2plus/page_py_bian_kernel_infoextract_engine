from typing import Generator, Any

from basic_support.data_access.connection.pool_impl.rdb_pool import rdb_dao_creator
from info_extract.abc_data_traverser import ABCDataTraverser
from info_extract.extract_results.dict_extract_result import DictExtractResult


class DBTraverser(ABCDataTraverser[Any, DictExtractResult]):

    def __init__(self, db_config, sql=None, name='数据库数据迭代器'):
        super(DBTraverser, self).__init__(name)
        self.db_config = db_config
        self.dao = rdb_dao_creator.get_rdb_pool(self.db_config)
        self.sql = sql

    def setSQL(self, sql):
        self.sql = sql

    def handle(self, content: DictExtractResult = None) -> Generator[DictExtractResult, None, None]:
        for i in self.dao.query_batch_iter(self.sql):
            if i:
                yield DictExtractResult(i)