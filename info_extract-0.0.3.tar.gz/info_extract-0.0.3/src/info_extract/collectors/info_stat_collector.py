from typing import Generator, Callable, List, Tuple, Any, Dict

from info_extract.abc_info_collector_batch_wrapper import ABCInfoCollectorBatchWrapper
from info_extract.abs_batch_condition import AbsBatchCondition
from info_extract.base_info_collector import BaseInfoCollector


class InfoStatCollector(ABCInfoCollectorBatchWrapper[Any, Any, Tuple[str, Any]]):

    def __init__(self, name, handler: BaseInfoCollector,
                 stat_func: Callable[[Any], List[Tuple[str, Any]] | Tuple[str, Any]] = None,
                 stat_to_result_func: Callable[[Dict], List[Dict]] = None,
                 condition: AbsBatchCondition = None, last_handle=True):

        self.stat_func = stat_func if stat_func else lambda data: (data, 1)

        def infos_to_result(infos):
            result = [{'KEY': k, 'VAL': v} for k, v in infos.items()]
            self.infos = {}
            return result

        def row_to_infos(one, infos):
            k, v = self.stat_func(one)
            if k:
                if k in infos:
                    infos[k] = infos[k] + v
                else:
                    infos[k] = v

        super(InfoStatCollector, self).__init__(
            name,
            handler,
            {},
            row_to_infos=row_to_infos,
            infos_to_result=stat_to_result_func if stat_to_result_func else infos_to_result,
            condition=condition,
            last_handle=last_handle)
