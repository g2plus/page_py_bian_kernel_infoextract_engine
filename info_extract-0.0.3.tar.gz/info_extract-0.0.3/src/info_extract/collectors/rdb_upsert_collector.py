from collections import namedtuple
from info_extract.abc_info_collector_batch_wrapper import ABCInfoCollectorBatchWrapper
from typing import Callable, Generator, List, Dict, Any, Set, Tuple
from info_extract.base_info_collector import BaseInfoCollector
from basic_support.data_access.connection.pool_impl.rdb_pool import rdb_dao_creator
SQLScript = namedtuple('SQLScript', ['sql', 'params'])

class RdbUpsertCollector(ABCInfoCollectorBatchWrapper[Any, Any, Dict]):
    def __init__(self,
                 handler: BaseInfoCollector,
                 db_config,
                 table_name: str,
                 conflict: Tuple[str,...],
                 row_wrap: Callable[[any], Dict],
                 ignore_cols: Set[str] = None,
                 update_cols: Tuple[str] = None,
                 batch_size: int = 1000,
                 begin_scripts: List[SQLScript] = None,
                 end_scripts: List[SQLScript] = None,
                 last_handle=False,
                 name='数据库upsert收集器'
                 ):
        super(RdbUpsertCollector, self).__init__(name, handler, [])
        self.db_config = db_config
        self.dao = rdb_dao_creator.get_rdb_pool(self.db_config)
        self.table_name = table_name
        assert conflict, '冲突字段不允许为空'
        assert row_wrap, '解析表达式不允许为空'
        self.conflict = conflict
        self.update_cols = update_cols
        self.row_wrap = row_wrap
        self.ignore_cols: Set[str] = ignore_cols or []
        self.batch_size = batch_size
        self.infos = []
        self.last_insert = last_handle
        self.begin_scripts = begin_scripts
        self.end_scripts = end_scripts
    
    def start(self):
        if self.begin_scripts:
            for sql in self.begin_scripts:
                self.dao.execute_sql_with_params_list(sql.sql, sql.params)
                
    def finish(self):
        if self.end_scripts:
            for sql in self.end_scripts:
                self.dao.execute_sql_with_params_list(sql.sql, sql.params)
    
    def wrap(self, data: List[Any] | Any) -> List[Dict] | Dict:
        row = None
        if self.row_wrap:
            if isinstance(data, list):
                row = []
                for one in data:
                    row.append(self.row_wrap(one))
            else:
                row = self.row_wrap(data)
        else:
            row = data

        if not isinstance(self.handler, ABCInfoCollectorBatchWrapper):
            if isinstance(row, list):
                self.infos.extend(row)
            elif row:
                self.infos.append(row)

            if not self.last_insert and len(self.infos) > self.batch_size:
                self.dao.upsert_batch(
                    self.table_name,
                    [
                        {
                            k: v for k, v in one.items() if k not in self.ignore_cols
                        } 
                        for one in self.infos
                    ],
                    self.conflict, 
                    update_cols=self.update_cols
                )
                self.infos = []

        return row
    
    def last_handle(self) -> List:

        infos = None
        if self.last_insert and isinstance(self.handler, ABCInfoCollectorBatchWrapper):
            infos = [self.row_wrap(info) for info in self.handler.is_last_handle()]
        else:
            infos = self.infos
        self.dao.upsert_batch(
            self.table_name,
            [
                {
                    k: v for k, v in one.items() if k not in self.ignore_cols
                } 
                for one in infos
            ],
            self.conflict, 
            update_cols=self.update_cols
        )



        return infos;
    