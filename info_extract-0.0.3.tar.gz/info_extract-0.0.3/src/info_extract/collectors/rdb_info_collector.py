from typing import Callable, Generator, List, Dict, Any

from basic_support.data_access.connection.pool_impl.rdb_pool import rdb_dao_creator

from info_extract.abc_info_collector_batch_wrapper import ABCInfoCollectorBatchWrapper
from info_extract.abs_batch_condition import AbsBatchCondition
from info_extract.base_info_collector import BaseInfoCollector
from collections import namedtuple

SQLScript = namedtuple('SQLScript', ['sql', 'params'])


class RdbInfoCollector(ABCInfoCollectorBatchWrapper[Any, Any, Dict]):

    def __init__(self, name,
                 handler: BaseInfoCollector,
                 db_config,
                 sql=None,
                 begin_scripts: List[SQLScript] = None,
                 end_scripts: List[SQLScript] = None,
                 row_wrap: Callable[[Any], Dict] = None,
                 condition: AbsBatchCondition = None,
                 last_handle=False):
        """
        数据库信息收集器
        :param name:名称
        :param db_config:数据库配置信息
        :param sql:入库语句
        :param last_handle:是否最后才插入数据，默认为false
        """
        self.dbConfig = db_config
        self.dao = rdb_dao_creator.get_rdb_pool(self.dbConfig)
        self.sql = sql
        self.row_wrap = row_wrap if row_wrap else lambda data: data
        self.begin_scripts = begin_scripts
        self.end_scripts = end_scripts

        def row_to_infos(row, infos: List):
            infos.append(self.row_wrap(row))

        def infos_to_result(infos: List):
            self.dao.execute_sql_with_params_list_multi_threads(self.sql, infos)
            result = []
            result.extend(infos)
            infos.clear()
            return result

        super(RdbInfoCollector, self).__init__(
            name, handler, [],
            row_to_infos=row_to_infos,
            infos_to_result=infos_to_result,
            condition=condition,
            last_handle=last_handle)

    def start(self):
        if self.begin_scripts:
            for sql in self.begin_scripts:
                self.dao.execute_sql_with_params_list(sql.sql, sql.params)

    def set_sql(self, sql):
        self.sql = sql

    def finish(self):
        if self.end_scripts:
            for sql in self.end_scripts:
                self.dao.execute_sql_with_params_list(sql.sql, sql.params)
