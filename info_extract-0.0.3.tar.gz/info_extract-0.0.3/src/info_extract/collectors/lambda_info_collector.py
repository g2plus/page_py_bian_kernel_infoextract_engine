from typing import Generator, Callable, List, Tuple, Any

from info_extract.abc_info_collector_wrapper import ABCInfoCollectorWrapper
from info_extract.base_info_collector import BaseInfoCollector


class LambdaInfoCollector(ABCInfoCollectorWrapper[Any, Any, Any]):

    def __init__(self, name, handler: BaseInfoCollector,
                 lambda_func: Callable[[Any], List[Any] | Any] = None):
        super(LambdaInfoCollector, self).__init__(
            name,
            handler)
        self.lambda_func = lambda_func

    def wrap(self, data: Any) -> List[Any] | Any:
        return self.lambda_func(data)


