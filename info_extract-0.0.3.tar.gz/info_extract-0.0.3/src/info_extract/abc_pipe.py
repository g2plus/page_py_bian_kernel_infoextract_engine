#!/usr/bin/env Python
# -- coding: utf-8 --

"""
@version: v1.0
@author: liwei
@file: abc_pipe.py
@Description: 
@time: 2023/8/4 10:15
"""
from typing import Generator, List

from info_extract.abc_generator_handler_combined import AbsGeneratorHandlerOrganize, ABCCombinedGeneratorHandler


class ABCPipe(ABCCombinedGeneratorHandler):

    def __init__(self, name,
                 backward_iteration=False,
                 handler_organize: AbsGeneratorHandlerOrganize = None,
                 is_iterator=True):
        """
        计算管道类，一个管道代表一个具体操作
        :param name:
        """
        super(ABCPipe, self).__init__(name=name, handler_organize=handler_organize, is_iterator=is_iterator)
        self.pre_pipe: ABCPipe = None
        self.next_pipe: ABCPipe = None
        self.backward_iteration = backward_iteration

    def self_handle(self, content) -> Generator:
        return self.handler_organize.handle(content)

    def handle(self, content=None) -> Generator:
        if not self.backward_iteration:
            if self.pre_pipe:
                gen = self.pre_pipe.handle(content)
                if self.is_iterator:
                    for c in gen:
                        yield from self.self_handle(c)
                else:
                    result = []
                    for c in gen:
                        for d in self.self_handle(c):
                            result.append(d)
                    yield result
            else:
                if self.is_iterator:
                    yield from self.self_handle(content)
                else:
                    result = []
                    for d in self.self_handle(content):
                        result.append(d)
                    yield result
        else:
            gen = self.self_handle(content)
            if self.next_pipe:
                if self.is_iterator:
                    for c in gen:
                        yield from self.next_pipe.handle(c)
                else:
                    c = [i for i in gen]
                    yield from self.next_pipe.handle(c)
            else:
                if self.is_iterator:
                    yield from gen
                else:
                    yield [i for i in gen]




    def start(self):
        if self.pre_pipe:
            self.pre_pipe.start()
        for h in self.handler_organize.iterator_handle():
            h.start()

    def finish(self):
        if self.pre_pipe:
            yield from self.pre_pipe.finish()
        for h in self.handler_organize.iterator_handle():
            gen = h.finish()
            if gen:
                yield from h.finish()
    def set_next_pipe(self, step):
        self.next_pipe = step
        step.set_pre_pipe(self)

    def set_pre_pipe(self, step):
        self.pre_pipe = step

    def get_next_pipe(self):
        return self.next_pipe

    def get_pre_pipe(self):
        return self.pre_pipe
