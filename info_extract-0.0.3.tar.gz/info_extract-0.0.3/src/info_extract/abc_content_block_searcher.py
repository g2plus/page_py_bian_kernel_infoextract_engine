from typing import List, TypeVar, Generic

from info_extract.abc_content_block import ABCContentBlock
from info_extract.abc_content_block_condition import ABCContentBlockCondition

class DefOutputCondition(ABCContentBlockCondition):
    """
    默认条件：都满足
    """

    def __init__(self, condition):
        super(DefOutputCondition, self).__init__('def', condition)

    def calCondition(self, content) -> int:
        if content:
            return content.length
        else:
            return -1


class DefEntryCondition(ABCContentBlockCondition):
    """
        默认条件：都满足
    """

    def __init__(self, condition):
        super(DefEntryCondition, self).__init__('def', condition)

    def calCondition(self, content) -> int:
        if content:
            return 0
        else:
            return -1


T = TypeVar('T')


class ABCContentBlockSearcher(Generic[T]):
    """
    提取块搜索器
    """

    def __init__(self, name):
        self.name = name
        self.entry_condition: T = None
        self.output_condition: T = None
        self.mid_condition: T = None

    def setEntryCondition(self, entry_condition: T):
        self.entry_condition = entry_condition

    def set_mid_condition(self, mid_condition: T):
        self.mid_condition = mid_condition

    def setOutputCondition(self, output_condition: T):
        self.output_condition = output_condition

    def getContent(self, result, start=0) -> List[ABCContentBlock]:
        pass
