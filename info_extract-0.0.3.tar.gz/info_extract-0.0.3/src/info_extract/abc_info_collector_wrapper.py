from typing import Generator, List, Any, TypeVar, Generic

from basic_support.logger.logger_config import logger

from info_extract.base_info_collector import BaseInfoCollector

EXTRACT_RESULT = TypeVar('EXTRACT_RESULT')
HANDLER_OUTPUT = TypeVar('HANDLER_OUTPUT')
OUTPUT = TypeVar('OUTPUT')


class ABCInfoCollectorWrapper(BaseInfoCollector[EXTRACT_RESULT, OUTPUT],
                              Generic[EXTRACT_RESULT, HANDLER_OUTPUT, OUTPUT]):
    def __init__(self, name, handler: BaseInfoCollector):
        """
        抽象迭代处理器，迭代处理逻辑的最抽象单元
        :param name:
        """
        super(ABCInfoCollectorWrapper, self).__init__(name)
        self.handler: BaseInfoCollector = handler

    def add_info(self, content: EXTRACT_RESULT = None) -> List[OUTPUT]:
        gen = self.handler.add_info(content)
        result = []
        for row in gen:
            logger.debug(self.handler.name + "，输出结果: %s", row)
            wrap_row = self.wrap(row)
            logger.debug(self.name + "，包装结果: %s", wrap_row)
            if isinstance(wrap_row, List):
                result.extend(wrap_row)
            else:
                result.append(wrap_row)
        return result

    def wrap(self, data: HANDLER_OUTPUT) -> List[OUTPUT] | OUTPUT:
        pass
