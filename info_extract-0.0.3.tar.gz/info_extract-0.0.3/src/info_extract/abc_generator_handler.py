#!/usr/bin/env Python
# -- coding: utf-8 --

"""
@version: v1.0
@author: liwei
@file: abc_generator_handler.py
@Description: 
@time: 2023/8/4 13:25
"""
from abc import ABCMeta, ABC
from typing import Generator, TypeVar, Generic

CONTENT = TypeVar('CONTENT')
RESULT = TypeVar('RESULT')


class ABCGeneratorHandler(
    Generic[CONTENT, RESULT],
    ABC, metaclass=ABCMeta):

    def __init__(self, name):
        """
        抽象迭代处理器，迭代处理逻辑的最抽象单元
        :param name:
        """
        self.name = name
        self.parent = None

    def init(self):
        pass

    def set_parent(self, parent):
        self.parent = parent

    def get_parent(self):
        return self.parent

    def handle(self, content: CONTENT = None) -> Generator[RESULT, None, None]:
        pass

    def print_structure_info(self, level=1):
        return ''.join(['\t' for i in range(level)]) + '[' + self.name + ']\n'

    def start(self):
        pass

    def finish(self):
        pass
