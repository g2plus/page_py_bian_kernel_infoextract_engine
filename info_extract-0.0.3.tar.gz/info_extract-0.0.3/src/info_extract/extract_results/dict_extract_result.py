


from info_extract.extract_result import ExtractResult


class DictExtractResult(ExtractResult):
    """字典型抽取结果
    :param _type_ ExtractResult: _description_
    """
    def __init__(self,data:dict):
        super().__init__()
        self.data = data