from typing import Generator, List

from basic_support.logger.logger_config import logger
from info_extract.abc_content_block import ABCContentBlock
from info_extract.abc_info_collector_batch_wrapper import ABCInfoCollectorBatchWrapper
from info_extract.abc_info_extractor import ABCInfoExtractor
from info_extract.extract_result import ExtractResult


class ABCSimpleInfoExtractor(ABCInfoExtractor):
    """简单单行抽取器"""

    def __init__(self, name):
        super(ABCSimpleInfoExtractor, self).__init__(name)
        # 是否过滤搜索到数据块的内容结果
        self.only_output_selected_content_block_row = False
        self.only_search_content_block = False

    def set_output_params(self,
                          only_search_content_block=True,
                          only_output_selected_content_block_row=True):
        """
        只输出搜索到数据块的内容结果
        :param only_search_content_block 只搜索内容块，不做规则提取
        :param only_output_selected_content_block_row: 只输出提取到内容块的数据
        :return:
        """
        self.only_search_content_block = only_search_content_block
        self.only_output_selected_content_block_row = only_output_selected_content_block_row



    def handle(self, content: ExtractResult) -> Generator:
        if content:
            output: ExtractResult = self.build_result(content)
            content_blocks: List[ABCContentBlock] = self.contentSearcher.getContent(content)
            selected = False
            while content_blocks:
                for contentBLock in content_blocks:
                    contentBLock.set_res_id(content.id)
                    contentBLock.add_include_columns(content.content)
                    if contentBLock.rule_type in self.search_filter_content_block_types:
                        output.add_content_block(contentBLock)
                        selected = True
                        logger.debug('【' + self.contentSearcher.name + "】搜索到内容块：%s", contentBLock)
                        if self.only_search_content_block is False \
                                and contentBLock.rule_type in self.extractRule:
                            rule = self.extractRule[contentBLock.rule_type]
                            rule_result = rule.extract(contentBLock)
                            if rule.name in self.info_collectors:
                                for collector in self.info_collectors[rule.name]:
                                    logger.debug('【' + collector.name + "】收集【%s】的信息：%s", rule.name, rule_result)
                                    collector.add_info(rule_result)
                            output.add_info(rule_result)
                content_blocks = self.contentSearcher.getContent(content, contentBLock.end)
            if self.only_output_selected_content_block_row is False or \
                    (self.only_output_selected_content_block_row is True and selected):
                self.wrap_result(output)
                logger.debug('【' + self.name + '】提取结果 -> %s', output)
                yield output


