#!/usr/bin/env Python
# -- coding: utf-8 --

"""
@version: v1.0
@author: liwei
@file: info_extract_step.py
@Description: 
@time: 2023/8/4 10:25
"""
from typing import Generator

from info_extract.abc_pipe import ABCPipe


class InfoExtractStep(ABCPipe):
    """抽取步驟"""

    def __init__(self, name, engine):
        super(InfoExtractStep, self).__init__(name)
        self.set_parent(engine)

