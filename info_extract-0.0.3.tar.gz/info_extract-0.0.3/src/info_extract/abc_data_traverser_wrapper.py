from typing import Generator, List, TypeVar, Generic

from basic_support.logger.logger_config import logger
from info_extract.extract_result import ExtractResult

from info_extract.abc_data_traverser import ABCDataTraverser

CONTENT = TypeVar('CONTENT', bound=ExtractResult)
RESULT = TypeVar('RESULT', bound=ExtractResult)


class ABCDataTraverserWrapper(ABCDataTraverser[CONTENT, RESULT], Generic[CONTENT, RESULT]):
    def __init__(self, handler: ABCDataTraverser, name):
        """
        抽象迭代处理器，迭代处理逻辑的最抽象单元
        :param name:
        """
        super(ABCDataTraverserWrapper, self).__init__(name)
        self.handler: ABCDataTraverser = handler
        self.total_count = 0
        self.log_size = 2000

    def start(self):
        self.handler.start()

    def finish(self):
        self.handler.finish()

    def handle(self, content: CONTENT = None) -> Generator[RESULT, None, None]:
        gen = self.handler.handle(content)
        yield from self.iterator_wrap(gen)

    def iterator_wrap(self, gen):
        for row in gen:
            logger.debug(self.handler.name + "，输出结果: %s", row)
            if isinstance(row, List) or isinstance(row, Generator):
                for one in row:
                    wrap_row = self.wrap(one)
                    if wrap_row:
                        self.total_count = self.total_count + 1
                        logger.debug(self.name + "，包装结果: %s", wrap_row)
                        if self.total_count % self.log_size == 0:
                            logger.info('[%s]已包装数据[%d]条' % (self.name, self.total_count))
                        yield wrap_row
            else:
                wrap_row = self.wrap(row)
                if wrap_row:
                    logger.debug(self.name + "，包装结果: %s", wrap_row)
                    if isinstance(wrap_row, List) or isinstance(wrap_row, Generator):
                        self.total_count = self.total_count + 1
                        if self.total_count % self.log_size == 0:
                            logger.info('[%s]已包装数据[%d]条' % (self.name, self.total_count))
                        yield from wrap_row
                    else:
                        self.total_count = self.total_count + 1
                        if self.total_count % self.log_size == 0:
                            logger.info('[%s]已包装数据[%d]条' % (self.name, self.total_count))
                        yield wrap_row

    def wrap(self, data: CONTENT) -> RESULT | Generator[RESULT, None, None] | List[RESULT]:
        raise Exception("ABCDataTraverserWrapper未实现的抽象方法！")
