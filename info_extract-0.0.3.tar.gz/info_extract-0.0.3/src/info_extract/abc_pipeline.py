#!/usr/bin/env Python
# -- coding: utf-8 --

"""
@version: v1.0
@author: liwei
@file: abc_pipe.py
@Description: 
@time: 2023/8/4 10:15
"""
from typing import Dict, Generator

from info_extract.abc_generator_handler_combined import ABCCombinedGeneratorHandler

from info_extract.abc_pipe import ABCPipe
from info_extract.abs_generator_handler_organize import AbsGeneratorHandlerOrganize


class ABCPipeline(ABCPipe):

    def __init__(self, name, backward_iteration=False,
                 handler_organize: AbsGeneratorHandlerOrganize = None,
                 is_iterator=True):
        """
        组合计算管道类，可以有多个子管道，组合复杂处理流程
        :param name:
        """
        super(ABCPipeline, self).__init__(name=name, handler_organize=handler_organize, is_iterator=is_iterator)
        self.last_pipe: ABCPipe = None
        self.first_pipe: ABCPipe = None
        self.backward_iteration = backward_iteration

    def init(self):
        cur_pipe = self.first_pipe
        while cur_pipe:
            cur_pipe.init()
            cur_pipe = cur_pipe.next_pipe

    def print_process(self):
        str = self.name + " 处理过程："
        cur_step = self.get_first_pipe()
        while cur_step:
            str = str + cur_step.name + " ->"
            cur_step = cur_step.get_next_pipe()
        return str

    def insert_first_pipe(self, first_pipe: ABCPipe,
                          group_name=ABCCombinedGeneratorHandler.GROUP_DEF):
        if self.first_pipe is None:  # 第一条
            self.first_pipe = first_pipe
            self.last_pipe = first_pipe
        else:
            pipe = self.first_pipe
            self.first_pipe = first_pipe
            pipe.set_pre_pipe(self.first_pipe)
        self._add_child(first_pipe, group_name)

    def add_child(self, last_pipe: ABCPipe,
                  group_name=ABCCombinedGeneratorHandler.GROUP_DEF):
        if self.first_pipe is None:
            self.insert_first_pipe(last_pipe, group_name)
        else:
            self.last_pipe.set_next_pipe(last_pipe)
            self.last_pipe = last_pipe
            self._add_child(last_pipe, group_name)

    def get_first_pipe(self):
        return self.first_pipe

    def get_last_pipe(self):
        return self.last_pipe

    def finish(self):
        yield from self.last_pipe.finish()

    def self_handle(self, content=None) -> Generator:
        if not self.backward_iteration:
            return self.last_pipe.handle(content)
        else:
            return self.first_pipe.handle(content)
