#!/usr/bin/env Python
# -- coding: utf-8 --

"""
@version: v1.0
@author: huangyc
@file: setup.py.py
@Description: https://blog.csdn.net/weixin_43940314/article/details/128349554
@time: 2023/8/2 8:46
"""
import shutil
from pathlib import Path

from setuptools import setup, find_packages

VERSION = '0.0.3'
DESCRIPTION = '抽取挖掘核心包'

dir_path = Path('.')
for file in dir_path.iterdir():
    # 避免缓存引起的奇怪问题
    if file.is_dir() and (file.name.endswith('egg-info') or file.name == 'build' or file.name == 'dist'):
        shutil.rmtree(file.name)
        print(f"删除[{file.name}]文件夹")

setup(
    # 包名称
    name="info-extract",
    # 包版本
    version=VERSION,
    # 包作者
    author="liwei",
    # 包的简单描述
    description=DESCRIPTION,
    # 包详细描述的内容类型
    long_description_content_type="text/markdown",
    # 包的详细描述
    long_description=open('README.md', encoding="UTF8").read(),

    # 需要打包的包
    # packages=find_packages(),
    packages=find_packages('src', exclude=find_packages(include=['tests', 'tests.*'])),
    # exclude_package_data={'tests': ['data_access/*']},
    package_dir={'': 'src'},

    # 安装时需要安装的依赖包
    install_requires=[],
    # include_package_data=True,
    # 其他 setup 配置
    # cmdclass={
    #     'clean': CleanCommand,
    # },

    # 包的关键词
    keywords=['info', 'mining', 'token'],
    # 打包时需要打包的数据文件，比如图片、配置文件等
    data_files=[],  #
    # 一个字典，用于定义你的 Python 项目的入口点。入口点允许你将某些功能或插件注册到特定的名称下，供其他程序或工具使用
    # 一个常见的使用场景是在你的项目中注册一个命令行工具
    entry_points={},
    # 授权信息
    license="MIT",
    # 官网地址
    url="https://www.github.com",
    # 指定可执行的脚本，安装时脚本会被安装到系统 PATH 路径下
    scripts=[],
    # 包所属分类列表：用于指定你的 Python 项目的分类信息
    # 这些分类信息通常用于指定你的项目适用于哪些操作系统、Python 版本、开发状态等
    classifiers=[
        "Development Status :: 3 - Alpha",
        "Intended Audience :: Developers",
        "Programming Language :: Python :: 3",
        "Operating System :: Microsoft :: Windows"
    ],
    platforms=['Windows', 'Linux'],
)

"""
entry_points和scripts有什么不一样
* entry_points：允许你将项目注册为一个命令行工具，并指定可执行的函数或方法
* scripts：允许你将指定的脚本复制到用户的可执行路径中，以便用户可以直接运行这些脚本
"""
